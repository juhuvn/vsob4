###########################################################################################
## This R script contains steps used in data analysis in the practical: 16S rRNA gene sequencing
## Use is restricted to VSOB4 course 2025 organised in ICISE Quy Nhon 
## Data are sourced from publication (doi: 10.1038/s41522-022-00351-7)
## Scripts are revised and updated based on previously published in Github (https://github.com/Hao-Chung/Vietnam_CRC_microbiome/) 
## Author: Hao Chung The
############################################################################################

##### Part 2: Explore diversity and conduct differential abundance analysis 
momo <- readRDS(file="./momo_27ENtutorial_phyloseq.RDS") ## read in the pre-defined phyloseq object called momo
momo ## 64 samples with 672 taxa

momo.mdn <- sample_sums(momo) %>% median() ## getting median of the sample size
standf <- function(x, t=momo.mdn) round(t* x/sum(x))
momo.prop <- transform_sample_counts(momo, standf) ## to the same size for each sample

### Calculating distance and Ordination
momo.bray <- phyloseq::distance(momo.prop, method='bray')
momo.wunifrac <- phyloseq::distance(momo.prop, method='wunifrac')
momo.ordb <- ordinate(momo.prop, 'PCoA', momo.bray)
momo.ordw <- ordinate(momo.prop, 'PCoA', momo.wunifrac)

## Generating a beta-diversity plot 
plot_scree(momo.ordb) ## top 2 Principal components account for 15% and 10% of variation
plot_ordination(physeq = momo.prop, ordination = momo.ordb, type="samples", color="sample_type") ## seems to be left-right separation

plot_scree(momo.ordw) ## top 2 Principal components account for 37%  and ~20% of variability 
plot_ordination(momo.prop, momo.ordw, type="samples", color='sample_type') ## seems to be separation on the second axis

## let's try the compositional data analysis approach
## construct ordination for all samples
## subset momo to include taxa that are present in at least 3 samples
momo1 <- prune_taxa(names(which(colSums(otu_table(momo) > 0) > 2)),momo)

summary(sample_sums(momo1)/sample_sums(momo)) ## median of 96% retention

## This follows tutorial for phILR calculation (see:https://www.bioconductor.org/packages/release/bioc/vignettes/philr/inst/doc/philr-intro.html)
otutab.philr <- cmultRepl(t(otu_table(momo1)), method="GBM", output='p-counts', z.delete=FALSE) ##impute zero count
otutab.philr %>% dim() ## 440 taxa across 64 samples
taxtab.philr <- tax_table(momo1)
## export tree from momo1, and insert node label on tree
tree.philr <- makeNodeLabel(as.phylo(phy_tree(momo1)), method="number", prefix='n')

## transform count data into phILR
gp <- philr(t(otutab.philr), tree.philr, part.weights="enorm.x.gm.counts", ilr.weights="blw.sqrt")
gp[1:10,1:10]
gp %>% dim()
## simple distance and ordination
gp.dist <- dist(gp, method="euclidean")
gp.ord <- ordinate(momo1, method="PCoA", distance=gp.dist)
plot_scree(gp.ord)

plot_ordination(momo1, gp.ord, type="samples", color="sample_type")

plot_ordination(momo1, gp.ord, type="samples", color="sample_type") + geom_point(size=1.5) + 
  theme_bw() + scale_color_manual(values=c("lightskyblue", "indianred4")) + 
  xlab("PCoA1 (31.4%)") + ylab("PCoA2 (14.5%)") + stat_ellipse(type="t", linetype=1) + 
  theme(legend.position = "bottom", legend.background = element_rect(color="gray90"))

## Differential abundance analysis using ANCOMBCII 
sample_data(momo)$Group <- factor(sample_data(momo)$Group, levels = c("control", "case"))


############## Differential abundance analysis ################
## Using ANCOMBC and then compare with DESeq2 results
anbc1 <- ancombc(data=momo, taxa_are_rows = FALSE, formula="Group", #
                 p_adj_method = 'holm', prv_cut=0.1, lib_cut=1000, ## remove taxa found in less than 10% of samples
                 group="Group",struc_zero = TRUE, neg_lb = FALSE, tol = 1e-5, ## keep structural zero = TRUE
                 max_iter = 200, conserve = TRUE, alpha = 0.05, global = FALSE, ## keep conserve=TRUE as recommended for small sample size/expected large number of output taxa
                 n_cl = 1, verbose = TRUE)
anbc1$res$diff_abn %>% head(n=10)

## use function to summarise output
anbc1.df <- output_ancombc(physeq = momo, anbc1, group = 'Groupcase')
anbc1.df

## Differential abundance using DESeq2
## put to the same criteria for ANCOMBC1 
momo2 <- prune_taxa(which(prevalence(momo, detection=0) > 0.1) %>% names(), momo)
momo2
summary(sample_sums(momo2)/sample_sums(momo)) ## median of 87% if 0.1 cutoff

## assess sparsity
length(which(abundances(momo2) ==0))/(nsamples(momo2)*ntaxa(momo2)) ## 74%, not too bad

## transform phyloseq data into DESeq2 object, with simple design
table(sample_data(momo2)$Group , sample_data(momo2)$sample_type) ## sampletype and group is interchangeable
ds <- phyloseq_to_deseq2(momo2, design = ~sample_type)
ds <- estimateSizeFactors(ds, type='poscounts') ## this is to correct for different sample sizes

## Conducting differential abundance test
ds <- DESeq(ds, test="Wald", minmu=0.5, minReplicatesForReplace = 7, fitType = "local", betaPrior = FALSE, useT=TRUE)
plotDispEsts(ds)
DESeq2::plotMA(ds)
resultsNames(ds) ## use the second element 
## using pre-defined function to output DESeq2 result
ds.res <- output_deseq2(momo2, ds, contrast = "sample_type_tumour_vs_biopsy", alpha=0.1, coef=2, testtype='apeglm') 
ds.res
ds.res$ASV ## taxa that are significant after DESEq2 

t1 <- intersect(ds.res$ASV, anbc1.df$taxon) ## taxa that are found in both ANCOMBC and DESeq2
ds.res[t1,]
diff.cons <- anbc1.df %>% filter(taxon %in% t1) ## use foldchange and adjusted p-values from ANCOMBC results

## plotting
colnames(diff.cons)[3] <- 'logFoldChange'
diff.cons <- diff.cons %>% arrange(desc(logFoldChange))
species.level <- diff.cons$Genus
diff.cons$Genus <- factor(diff.cons$Genus, levels=species.level)
diff.cons$type <- c(1,1,1,1,0)
ggplot(diff.cons, aes(Genus, logFoldChange, fill=factor(type))) + geom_bar(stat="identity") + coord_flip() + 
  theme_bw() + theme(axis.text.x=element_text(angle=0, size=12, vjust=1, hjust=1 ), legend.position = 'none') + 
  scale_fill_manual(values=c("gray9", "lightcoral"), labels=c("no", "yes"), guide=guide_legend(title="Oral microbiome", label.position="bottom"))
