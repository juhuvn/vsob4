###########################################################################################
## This R script contains steps used in data analysis in the practical: 16S rRNA gene sequencing
## Use is restricted to VSOB4 course 2025 organised in ICISE Quy Nhon 
## Data are sourced from publication (doi: 10.1038/s41522-022-00351-7)
## Scripts are revised and updated based on previously published in Github (https://github.com/Hao-Chung/Vietnam_CRC_microbiome/) 
## Author: Hao Chung The
############################################################################################

## Initiate by loading the necessary libraries
library(stringr) ## manipulating strings
library(dplyr) ## general utility
library(dada2) ## MAIN package for generating amplicon sequence variants from fastq input
library(phyloseq) ## MAIN package for integrating microbiome with metadata, and general functions
library(RColorBrewer) ## for color palette 
library(seqinr) ## read in and output sequences in R
library(ranacapa) ## use ggrare function for rarefaction curve
library(phytools) ## read in phylogeny in newick format
library(philr) ## to perform ILR transformation 
library(zCompositions) ## general utility for compositional data analysis
library(ANCOMBC) ## MAIN package: Differential abundance analysis
library(microbiome) ## general utility for handling phyloseq objects
library(DESeq2) ## MAIN package: Differential abundance analysis 
library(apeglm) ## for handling results from DESeq2

## download trimmed sequencing data from Dropbox 
## Data include 43 cases (colorectal tumour) and 25 control (non-polyp biopsy) microbomes (>600 MB)

url <- "https://www.dropbox.com/scl/fi/ix0lvxoeyj3k4d4b5wphp/biopsy_CRC_tutorial.zip?rlkey=fvgtoap56xda1assotbpyuu7m&st=6l023qsv&dl=1" 
destfile <- "biopsy_CRC_tutorial.zip"
download.file(url, destfile, mode="wb") ## download data into the current working directory. 'wb' for binary file
unzip("./biopsy_CRC_tutorial.zip", exdir=getwd()) ## unzip folder to the current directory

## Download and read in the SILVA trainset database. This is formatted by DADA2 team already
silva_url <- "https://www.dropbox.com/scl/fi/5hdvb87rsmt1d4z3576mf/silva_nr99_v138.2_toSpecies_trainset.fa.gz?rlkey=6o6dnoxqypa4whp19uct38leg&st=ijytl68t&dl=1"
download.file(silva_url, "./silva_nr99_v138.2_toSpecies_trainset.fa.gz", mode="wb")

## read in sequencing data
path <- "./data_seq_tutorial/" 
list.files(path)

## Forward and reverse fastq file names have format ${x}_1.fastq.gz and ${x}_2.fastq.gz
fnFs <- sort(list.files(path, pattern="_1.fastq.gz", full.names=TRUE)) ## forward reads
fnRs <- sort(list.files(path, pattern="_2.fastq.gz", full.names=TRUE)) ## reverse reads
## Extract sample names, assuming file names have consistent format
sample.names <- sapply(strsplit(basename(fnFs), "_"),`[`,1) ## split string (names) by "_", then apply to each element to only select the first component

## Have a look of the data
plotQualityProfile(fnFs[1:2])
plotQualityProfile(fnRs[5:8])

## Remove the primer on forward and reverse independently, using a fixed cut-off in length for each sequence.
filt.fwd <- str_c(sample.names, "_noprimer_1.fastq.gz", sep="") ## file names for forward reads after filtering
filt.rev <- str_c(sample.names, "_noprimer_2.fastq.gz", sep="") ## file names for reverse reads after filtering

## Truncate the length of forward and reverse reads to retain only high quality reads, as well as removing primers
## Forward reads show good quality, so only trim the last 10 bp
## Reverse reads show much poorer quality, so decide to trim 100 bp at the end to retain mostly quality >30
## Primers for primary PCR are "GTGYCAGCMGCCGCGGTAA" (515F, 19 characters) and "GGACTACNVGGGTWTCTAAT" (806R, 20 characters)
## Other parameters are as the default recommendation by dada2
## keep maxEE=c(2,2) for conservative DADA2 option: maximum number of expected errors allowed in a read

filterout <- filterAndTrim(fnFs, filt.fwd, fnRs, filt.rev, truncLen = c(240,150),
                           maxEE=c(2,2), maxN=0, trimLeft = c(19,20), rm.phix = TRUE, multithread = TRUE, compress=TRUE)
## print out result
## turning filterout into a dataframe, and create a new column to assess retention after filtering
F1 <- filterout %>% data.frame() %>% mutate(retain= round(reads.out/reads.in*100,1))
F1 %>% pull(retain) %>% summary() ## summarising the retention rate: ~70% of reads retained

## Denote the new path for the fastq files that have removed the primers
fwdfin <- sort(list.files("./", pattern="_noprimer_1.fastq.gz", full.names=TRUE))
revfin <- sort(list.files("./", pattern="_noprimer_2.fastq.gz", full.names=TRUE))

## Have a look of the noprimer data 
plotQualityProfile(fwdfin[1:2])
plotQualityProfile(revfin[5:8])

## Learn the error rates using the trimmed noprimer sequences. This can take around 5-10 minutes to complete
errF <- learnErrors(fwdfin, multithread = TRUE) 
errR <- learnErrors(revfin, multithread = TRUE)
plotErrors(errF, nominalQ = TRUE)
plotErrors(errR, nominalQ = TRUE)

## Sample inference, default is without pooling
dadaFs <- dada(fwdfin, err = errF, multithread = TRUE)
dadaRs <- dada(revfin, err = errR, multithread = TRUE)

## Merging paired reads
## Allow for maximum of 2 mismatches in the overlap region to account for possible sequencing errors, also due to small library sizes
mergers <- mergePairs(dadaFs, fwdfin, dadaRs, revfin, verbose=TRUE, maxMismatch = 2, returnRejects = FALSE)

seqtab <- makeSequenceTable(mergers) ## creating a sequence x sample table
dim(seqtab) ## 75 samples with 6,379 unique sequences
seqtab[1:5,1:10]
table(nchar(getSequences(seqtab))) # most of the unique sequences still fall into the bacterial 16S expected size (251-256)
seqfasta <- getSequences(seqtab) ## output the sequences 

### The next step is to classify each merged read to their taxonomic ranks
## It is expected that non-specific, non-bacterial sequences can be quite high, since tissues mainly contain host DNA

## Classify each sequences up to the species level by comparing to the silva database
taxa <- assignTaxonomy(seqtab, "./silva_nr99_v138.2_toSpecies_trainset.fa.gz", multithread = TRUE, outputBootstraps = TRUE)

## screening to retain only bacterial sequences
## Output from this function is a list, with [[1]] the filtered sequence file, and [[2]] the filtered taxonomic file
seqfastafil <- screen_nonbacteria(taxofile = taxa, seqfile = seqfasta)[[1]]
taxafil <- screen_nonbacteria(taxa, seqfasta)[[2]]

length(seqfastafil) ## >4,000 sequences
taxafil$tax %>% dim() ## 

seqtabfil <- seqtab[,match(seqfastafil, colnames(seqtab))] ## extract only nonbacteria to create a new sequence tab
sum(seqtabfil)/sum(seqtab) ## retention of 80%

table(nchar(getSequences(seqtabfil))) ## a few sequences outside the range, but mostly within the Kingdom Bacteria
taxafil$tax[which(nchar(seqfastafil) > 254),]
taxafil$tax[which(nchar(seqfastafil) < 251),]

#### Detection and removal of chimera
## use default settings to detect and remove chimera 
seqtab_nochim <- removeBimeraDenovo(seqtabfil, method="consensus", multithread=TRUE, minFoldParentOverAbundance=4)
seqtab_nochim %>% dim()
sum(seqtab_nochim)/sum(seqtabfil) ## 96%, low chimera level

### summary statistics 
getN <- function(x) sum(getUniques(x))
track <- cbind(filterout, sapply(dadaFs, getN), sapply(dadaRs, getN), sapply(mergers, getN), rowSums(seqtabfil), rowSums(seqtab_nochim))
colnames(track) <- c("input", "filtered", "denoisedF", "denoisedR", "merged", "screened", "nonchim")
rownames(track) <- sample.names
track <- as.data.frame(track)
head(track)

track <- track %>% mutate(retention = round(nonchim/input*100,1))
track %>% pull(retention) %>% summary() ## roughly 50% read loss after filtering 

## plotting graph to detail retention of reads after each filtering row
library(reshape2)
track$sample <- rownames(track)
track.m <- melt(track[,-c(8)], id.vars="sample") ## notusing the retention percentage column
colnames(track.m)[2] <- "filtering"
## Plotting boxplot
ggplot(track.m, aes(x=filtering, y=value, fill=filtering)) + geom_boxplot() + 
  scale_fill_manual(values = brewer.pal(name = "Set3", n=7)) + 
  xlab("Processing steps") + ylab("Read count") + theme_bw()

#######################################################
### Proceed to create a phyloseq object to use the nonchimeric dataset
ps <- phyloseq(otu_table(seqtab_nochim, taxa_are_rows=FALSE), tax_table(taxa$tax))
taxa_names(ps) ## taxa_names are currently sequences. These are too long and need to be shortened
taxa_names(ps) <- sprintf("seq%05d", 1:ntaxa(ps)) ## create a new set of taxa names
otu_table(ps)[1:2,1:10]
tax_table(ps)[1:5,]

## replace sample names with more direct naming
sample_names(ps) <- sample.names
sample_names(ps)

## Import sample data
metatut <- read.csv(file="./tutorial_27EN_metadata.csv", header=TRUE, stringsAsFactors = FALSE)
rownames(metatut) <- metatut$sample_ID ## need to match sample_names(ps) with rownames of the metadata dataframe
metatut <- metatut[,-c(1)] ## remove the first column since it is redundant now
head(metatut)

## Sanity check 
rownames(metatut) %in% sample_names(ps) ## last element in rownames(metatut) does not match
rownames(metatut)  
sample_names(ps) ## rowname should be NTC-Primary
## A bit editing to match rownames and sample_names
rownames(metatut)[nrow(metatut)] <- "NTC-Primary"
rownames(metatut) %in% sample_names(ps) ## all true
## input sample_data into phyloseq
sample_data(ps) <- sample_data(metatut) 
sample_data(ps)
ps ## 1856 taxa 

#########################################
##### Let's look at controls first
## positive control
mock.only <- prune_samples(samples = 'Zymo',x = ps) ## only subsetting the Zymo positive control
mock.only <- prune_taxa(taxa_sums(mock.only)>0, mock.only) ## to remove taxa that are not present in the subsetted phyloseq object
otu_table(mock.only) ## a few taxa with very low abundance, likely sequencing errors or minor contamination 
tax_table(mock.only)

### remove taxa with low abundance, threshold at 100
mock.only <- prune_taxa(taxa_sums(mock.only)>100, mock.only )
otu_table(mock.only)
plot_bar(mock.only, fill='Genus') + geom_bar(aes(colour=Genus, fill=Genus), stat='identity', position='stack') + 
  scale_fill_manual(values = brewer.pal(n=8, name='Set3')) + 
  scale_color_manual(values=brewer.pal(n=8, name='Set3')) + theme_bw() + 
  xlab("Mock community") + ylab("Abundance")

## The identity matches that of positive control, but composition is not at exact 12.5% for each genus

##############################################
keep1 <- prune_samples(sample_names(ps)!= 'Zymo', ps) ## now removing positive control
keep1 <- prune_taxa(taxa_sums(keep1) >0, keep1)

## Inspect what are present in the negative control samples
blanks <- sample_names(keep1)[which(sample_data(ps)$sample_type == 'negative')]
blankid <- which(colSums(otu_table(keep1)[blanks,]) > 0) %>% names() ## 
blankid %>% length() ## 128 taxa
blank_genus <- tax_table(keep1)[blankid,"Genus"] %>% table() %>% names() ## to output the genus of blankid

## write a function to investigate the prevalence and mean relative abundance of these genera
keep1.glom <- tax_glom(keep1, taxrank = "Genus") ## aggregating taxa into genus level
keep1.glom <- transform_sample_counts(keep1.glom, function(x) x/sum(x)) ## transform data into proportional 
keep1.glom # 311 unique genera

## A small inspection 
blank.presence <- c()
blank.abund <- c()
blank.noseq <- c()
blankgenusId <- list()
for (x in blank_genus) {
  blank.presence[x] <- length(which(otu_table(keep1.glom)[,tax_table(keep1.glom)[,"Genus"] == x]>0)) ## present in how many samples
  temp <- otu_table(keep1.glom)[,tax_table(keep1.glom)[,"Genus"] == x] %>% as.vector()
  blank.abund[x] <- temp[temp!=0] %>% mean() ## the mean proportion of the genus
  blankgenusId[[x]] <- taxa_names(keep1)[which(tax_table(keep1)[,"Genus"] == x)] ## breakdown of genus and the associated taxa
  blank.noseq[x] <- length(taxa_names(keep1)[which(tax_table(keep1)[,"Genus"] == x)]) ## no of ASV taxa matching the genus
}
blank.presence 
blank.abund
blank.noseq
blankgenusId

## Based on assessment of genera found in negative controls and prior knowledge on the bacterial composition of the microbiome samples
## Read in a predefined list of likely contaminated genera
contamgenus <- read.csv(file="./27EN_contam_genus.csv")
contamgenus <- contamgenus$contam_genus

blank.presence <- blank.presence %>% data.frame()
colnames(blank.presence) <- 
blank.presence$Genus <- rownames(blank.presence) 


## Double check taxa that are likely true componenets of the microbiome
blank_genus[!(blank_genus %in% contamgenus)] ## make sense, so remove sequences classified as in contamgenus

## save it as keep2
keep2 <- prune_samples(!(sample_names(keep1) %in% blanks), keep1) ## remove negative controls
keep2 <- prune_taxa(!(tax_table(keep2)[, "Genus"] %in% contamgenus), keep2) ## remove taxa belonging to genera that are contamination
keep2 <- prune_taxa(taxa_sums(keep2)>0, keep2)

(sample_sums(keep2)/prune_samples(!(sample_names(keep1) %in% blanks),keep1) %>% sample_sums()) %>% sort() # retention is not bad. 

###### Rarefaction to assess saturation 
muco.ggrare <- ggrare(keep2, step=100, label=NULL, color="Group")
muco.ggrare + xlim(0,5000) ## let's put a threshold at 2,500 reads, seems reasonable

sample_sums(keep2) %>% sort() 
keep3 <- prune_samples(sample_sums(keep2) > 2500, keep2)
keep3 <- prune_taxa(taxa_sums(keep3) >0, keep3)
keep3 ## 1686 taxa in 64 samples

## Use this to estimate alpha-diversity first
## important to scale to the same library size for calculating alpha diversity
## Also not to perform further filtering at this step, should maximise diversity here
mdn <- sample_sums(keep3) %>% median() ## median of sample sizes
standf <- function(x, t=mdn) round(t* x/sum(x))
keep3.prop <- transform_sample_counts(keep3, standf) ## transform to put all sample to the same sequencing depth
plot_richness(keep3.prop, measures=c("Shannon", "Observed"), color="Group")  ## look like it is not much different

## output the exact readings of Shannon and observed richness
sample_data(keep3.prop)$Shannon <- as.vector(estimate_richness(keep3.prop, measures="Shannon") %>% as.matrix())
sample_data(keep3.prop)$richness <- as.vector(estimate_richness(keep3.prop, measures="Observed") %>% as.matrix())

## output sample_data into a dataframe for easier handling
df1 <- data.frame(sample_data(keep3.prop))
with(df1, wilcox.test(Shannon ~ Group)) ## p > 0.7 no significance
with(df1, wilcox.test(richness ~ Group)) ## NS 

## to remove Archaea as well 
taxa_names(keep1.glom)[tax_table(keep1.glom)[,"Genus"] == 'Methanobrevibacter'] ## seq00025
otu_table(keep1.glom)[,'seq00025'] %>% data.frame() %>% filter(seq00025 >0) %>% pull(seq00025) %>% mean() ## around 1%
keep4 <- prune_taxa(taxa_names(keep3)[tax_table(keep3)[,1] != "Archaea"], keep3) ## remove Archaea 
keep4

## The processed phyloseq still contains a lot of taxa. This makes processing, especially for phylogenetic tree, quite challenging
## Due to the sparsity of ASV data, alot of taxa are present in only one sample 
singletons <- which(colSums(otu_table(keep4)>0)==1) %>% names()
singletons %>% length() ## 1027 singletons

taxa_sums(keep4) %>% as.vector() %>% summary() ## median is 23 [7  - 128] ## 25% of taxa > 127 sequences. Select the third quartile
low1 <- which(taxa_sums(keep4) < 127) %>% names() ## define low as taxa that have sum less than the third quartile
singlelow <- intersect(singletons, low1) ## intersection between the two
singlelow %>% length() ## 1001 taxa 

keep4.dt <- transform_sample_counts(keep4, function(x) x/sum(x))
## for all singleton taxa, look at the relative contribution of them to the respective sample
sing.rela <- do.call(cbind, lapply(singletons, function(x) otu_table(keep4.dt)[,x] %>% as.data.frame() %>% filter(.>0)))
sing.rela[singlelow] %>% unlist() %>% summary() ## max is 3%. So it is pretty safe to remove from samples

keep5 <- prune_taxa(!(taxa_names(keep4) %in% singlelow), keep4) ## remove singleton taxa that do not contribute much to the sample's overall composition
seqtokeep <- as.numeric(str_extract(taxa_names(keep5), "[0-9]+"))
sequences <- getSequences(seqtab_nochim)[seqtokeep]
sequences <- as.list(sequences) ## 674 seqs 
sequences[[1]]

############ This section is for constructing tree and incorporating tree into phyloseq
## Output fasta file outside of R 
## write.fasta(sequences = sequences, names=taxa_names(keep5), file.out = "./27EN_keepseq.fasta", open='w')
## output fasta will be input into mafft for alignment 
## In UNIX command line:: 
## mafft-qinsi --maxiterate 500 --thread 12 27EN_keepseq.fasta > 27EN_keepseq_709seq.mafft.fasta ## alignment 
## draw tree using iqtree : iqtree -s 27EN_keepseq_709seq.mafft.fasta -bb 1000 -alrt 1000 -nt AUTO ## draw tree using iqtree2 

##### input tree
# tree <- read.newick(file="./27EN_keepseq_707_mafft_iqtree.newick")
# all(taxa_names(keep5) %in% tree$tip.label) ## all true
# tree2 <- drop.tip(tree, tree$tip.label[!(tree$tip.label %in% taxa_names(keep5))])
# phy_tree(keep5) <- phy_tree(tree2)
# keep5 ## use this to move forward to beta-diversity and differential abundance analysis 

########## After this 
# momo <- keep5
