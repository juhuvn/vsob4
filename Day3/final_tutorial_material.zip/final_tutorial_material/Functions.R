### This R script contains functions to be used in the practical
## Author: Hao Chung The

## Remove non-bacterial taxa from output of DADA2 
screen_nonbacteria <- function(taxofile, seqfile) { ## take in taxonomy file and sequence file
  require(tidyr) ## loading required libraries 
  require(dada2)
  rownames(taxofile$boot) <- NULL
  rownames(taxofile$tax) <- NULL
  euka_id <- which(taxofile$tax[,1] == "Eukaryota") ## Kingdom as Eukaryota
  ## NA classification at Kingdom, Phylum, Class, Order level
  naKing_id <- c(which(is.na(taxofile$tax[,1])), which(is.na(taxofile$tax[,2])), which(is.na(taxofile$tax[,3])), which(is.na(taxofile$tax[,4]))) %>% unique()
  mito_id <- which(taxofile$tax[,5] == "Mitochondria") ## mitochondrial sequences
  chloro_id <- which(taxofile$tax[,2] == "Chloroplast") ## chloroplast sequences 
  IDtorm <- c(euka_id, naKing_id, mito_id, chloro_id, naPhyl_id) %>% unique() ## combining these IDs
  IDtoretain <- c(1:length(seqfile))[-IDtorm] ## substractive to output retaining taxa
  seq2rm <- seqfile[IDtorm]
  seqretain <- seqfile[IDtoretain] ## sequences to retain
  ## output the taxonomic file as well for the retain sequences
  newtaxo <- list(taxofile$tax[IDtoretain,], taxofile$boot[IDtoretain, ]) ## create new taxonomy file to retain
  names(newtaxo) <- c("tax", "boot")
  #return(IDtoretain)
  return(list(seqretain,newtaxo))
}

## This function is used to calculate the relative abundances of taxa in a given sample
profile_by_relabund <- function(phyloseq, sample) { ## take in phyloseq data and a sample name
  require(dplyr)
  tax.present <- which(otu_table(phyloseq)[sample,] > 0)
  taxnames <- taxa_names(phyloseq)[tax.present]
  shortnames <- tax_table(phyloseq)[tax.present, c(6,7)] %>% as.data.frame() %>% apply(1, function(x) paste(x, collapse="_"))
  tot <- sample_sums(phyloseq)[sample]
  res <- round(otu_table(phyloseq)[sample,taxnames]/tot *100 , digits = 3)
  res <- res %>% as.data.frame()
  sname_order <- res %>% as.matrix() %>% order(decreasing = TRUE) ## to output taxa names in decreasing order of relative abundance
  newnames <- str_c(colnames(res), shortnames[match(colnames(res), names(shortnames))], sep="_") ## append genus and species names
  colnames(res) <- newnames
  res <- res[,sname_order]
  return(res)
}

## This function used for creating understandable results from DESeq2 output
output_deseq2 <- function(physeq, ds, contrast, alpha, coef, testtype) {
  require(phyloseq)
  require(DESeq2)
  rs <- results(ds, name=contrast, alpha=alpha, pAdjustMethod ="BH")
  rs_shrink <- lfcShrink(dds=ds, res=rs, coef=coef, type=testtype) ## correcting log2foldchange
  rs_shrink <- rs_shrink[order(rs_shrink$padj, na.last=T),]
  rs_shrink$prank <- seq(1,nrow(rs_shrink))
  rs_shrink$ASV <- rownames(rs_shrink)
  rs_shrink <- as.data.frame(rs_shrink)
  rs_shrink <- rs_shrink[!is.na(rs_shrink$padj),]
  rs_shrink <- rs_shrink[rs_shrink$padj < alpha,]
  rs_shrink$Genus <- tax_table(physeq)[rownames(rs_shrink), "Genus"]
  rs_shrink$Species <- tax_table(physeq)[rownames(rs_shrink), "Species"]
  return(rs_shrink)
}

## This function is used to create understandable results from ANCOMBC output
output_ancombc <- function(physeq, ancom.out, group){
  require(ANCOMBC)
  require(dplyr)
  diffid <- ancom.out$res$diff_abn %>% filter(!!sym(group)==TRUE) %>% pull(taxon)
  rs <- ancom.out$res$lfc %>% filter(taxon %in% diffid) 
  rs$se <- ancom.out$res$se %>% filter(taxon %in% diffid) %>% pull(!!sym(group))
  rs$qvalue <- ancom.out$res$q_val %>% filter(taxon %in% diffid) %>% pull(!!sym(group))
  rs$W <- ancom.out$res$W %>% filter(taxon %in% diffid) %>% pull(!!sym(group))
  rs$Genus <- tax_table(physeq)[diffid, c(6,7)] %>% as.data.frame() %>% apply(1, function(x) paste(x, collapse="_"))
  return(rs)
}

